"""FloodLens V2 fetch. Run ON YOUR PC (needs internet). From repo root:  python data/v2/v2_fetch.py [obs|rain]
 obs : USGS continuous stage(00065)/discharge(00060), 2023-02-01 -> today, for gauges in upstream_pair_lags.csv (usable upstream + targets). Same OGC endpoint as src/03_observed.py.
 rain: Open-Meteo Previous-Runs API, archived GFS precipitation forecasts at lead day 1..3, hourly, one point per gauge (lat/lon from derived/gauge_crosswalk.csv).
       UNVERIFIED: variable name 'precipitation_previous_dayN' and models=gfs_seamless are inferred from docs (open-meteo.com/en/docs/previous-runs-api); test one gauge first.
Leakage rule: precip_prev_dayN = forecast issued N days before valid hour -> safe to use as a feature at issue time. NEVER use observed rainfall as a forecast.
"""
import sys, io, time, pathlib, requests, pandas as pd
D = pathlib.Path("data"); OUT = D / "v2"; OUT.mkdir(exist_ok=True, parents=True)
USGS = "https://api.waterdata.usgs.gov/ogcapi/v0/"
cw = pd.read_csv(D / "derived/gauge_crosswalk.csv", dtype={"usgs_id": str})
lags = pd.read_csv(OUT / "upstream_pair_lags.csv", dtype=str)
ids = sorted(set(lags.usgs_id) | set(lags[lags.usable == "True"].up_id))

def obs():
    end = pd.Timestamp.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")
    for uid in ids:
        for pc in ("00060", "00065"):
            f = OUT / "raw_obs" / f"{uid}_{pc}.csv"; f.parent.mkdir(exist_ok=True)
            if f.exists(): continue
            parts, off = [], 0
            while True:
                r = requests.get(USGS + "collections/continuous/items", params={"f": "csv", "monitoring_location_id": f"USGS-{uid}",
                    "parameter_code": pc, "properties": "time,value", "time": f"2023-02-01T00:00:00Z/{end}", "limit": 50000, "offset": off}, timeout=300)
                if r.status_code == 429: time.sleep(60); continue
                r.raise_for_status(); d = pd.read_csv(io.StringIO(r.text)) if r.text.strip() else pd.DataFrame(columns=["time", "value"])
                parts.append(d); off += 50000
                if len(d) < 50000: break
            pd.concat(parts).to_csv(f, index=False); print(uid, pc, sum(map(len, parts)), flush=True)

def rain():
    rows = []
    for r in cw[cw.usgs_id.isin(ids)].itertuples():
        for a, b in (("2021-03-24", "2022-12-31"), ("2023-01-01", "2024-12-31"), ("2025-01-01", pd.Timestamp.utcnow().strftime("%Y-%m-%d"))):
            h = "precipitation," + ",".join(f"precipitation_previous_day{k}" for k in (1, 2, 3))
            j = requests.get("https://previous-runs-api.open-meteo.com/v1/forecast", params={"latitude": r.lat, "longitude": r.lon,
                "start_date": a, "end_date": b, "hourly": h, "models": "gfs_seamless", "timezone": "UTC"}, timeout=120).json()
            if "hourly" not in j: print("FAIL", r.usgs_id, a, j); continue
            d = pd.DataFrame(j["hourly"]); d["usgs_id"] = r.usgs_id; rows.append(d)
        print(r.usgs_id, flush=True); time.sleep(1)
    pd.concat(rows).rename(columns={"time": "time_utc"}).to_parquet(OUT / "rain_fcst_gfs_prevruns.parquet", index=False)

if __name__ == "__main__": {"obs": obs, "rain": rain}[sys.argv[1]]()
