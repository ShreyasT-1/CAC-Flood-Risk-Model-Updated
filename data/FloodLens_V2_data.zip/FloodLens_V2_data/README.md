# FloodLens V2 data pack (built 2026-10-13)

## Audit of existing data (what you already have)
| V2 need | Status | Evidence |
|---|---|---|
| Observed river levels | HAVE 2015-01-01 -> 2023-01-31 only | derived/obs_hourly.parquet: 16.7M rows, 236 gauges, stage+Q hourly, ~98.5% Q coverage (obs_coverage_2015_2023.csv). Nothing after 2023-01-31. |
| Upstream gauges | HAVE, NLDI upstream-navigation based | derived/upstream_gauges.csv (245 pairs, up to 3/gauge). Ranked by straight-line distance, not along-channel. |
| Rainfall forecasts | MISSING | forecasts/*.parquet are NWM *streamflow* forecasts, not rainfall. |

## New in this pack
- upstream_pair_lags.csv: for each upstream pair, empirical travel-time lag (hours, 0-96) maximizing correlation of 3h log-discharge changes, plus lag_corr, n_overlap_h, `usable` (corr>=0.3 and >=20,000 overlapping hours). 120/245 pairs usable; 69 of 108 target gauges have >=1 usable upstream. 60 pairs have no overlap data (a gauge lacks Q).
- obs_coverage_2015_2023.csv: per-gauge hours of discharge data.
- v2_fetch.py: downloads I could NOT run (my sandbox blocks USGS/NOAA/Open-Meteo hosts):
  `python data/v2/v2_fetch.py obs`  -> USGS 2023-02 -> now
  `python data/v2/v2_fetch.py rain` -> archived GFS precip forecasts, lead day 1-3, via Open-Meteo Previous-Runs API.

## Caveats (read these)
- v2_fetch.py is UNTESTED. Rain variable names are inferred from docs; run one gauge first.
- Lag is a correlation estimate, not hydraulic routing; lags of 0-1h on small basins mean the 3h resolution can't resolve travel time.
- Archived GFS precip forecasts start 2021-03, so your 2015-2023 obs only overlap 2021-03 -> 2023-01. That's why `obs` extension is needed before training with rainfall.
- Open-Meteo is point data at the gauge, not basin-averaged; non-commercial license terms apply.
- Better-but-heavier alternative for historical rainfall forecasts: NWM forcing_short_range on the GCS bucket you already use, or NBM/HRRR GRIB on AWS.
